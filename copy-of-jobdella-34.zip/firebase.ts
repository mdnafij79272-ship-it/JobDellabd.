
import { initializeApp, FirebaseApp } from "firebase/app";
import { getAuth as _getAuth, Auth, User, updateProfile as _updateProfile } from "firebase/auth";
import { getFirestore, Firestore, FieldValue, Timestamp, serverTimestamp as _serverTimestamp, increment as _increment, deleteField as _deleteField, collection as _collection, doc as _doc, query as _query, where as _where, orderBy as _orderBy, limit as _limit, onSnapshot as _onSnapshot, addDoc as _addDoc, getDoc as _getDoc, getDocs as _getDocs, setDoc as _setDoc, updateDoc as _updateDoc, deleteDoc as _deleteDoc, runTransaction as _runTransaction, writeBatch as _writeBatch } from "firebase/firestore";
import { getAnalytics as _getAnalytics, Analytics } from "firebase/analytics";

const firebaseConfig = {
  apiKey: "AIzaSyB7MJ9Mt-OHZz_fMT7UCTU7Ag7BMn_CD-0",
  authDomain: "jobdella-cb517.firebaseapp.com",
  projectId: "jobdella-cb517",
  storageBucket: "jobdella-cb517.firebasestorage.app",
  messagingSenderId: "767080163501",
  appId: "1:767080163501:web:3a90c72399c3693e313e24",
  measurementId: "G-YQQLEBKPDQ"
};

let resolveFirebaseReady: (() => void) | null = null;
export const firebaseInitializedPromise = new Promise<void>(resolve => {
    resolveFirebaseReady = resolve;
});

// Initialize Firebase app once
const app: FirebaseApp = initializeApp(firebaseConfig);

// Get service instances
const authInstance: Auth = _getAuth(app);
const dbInstance: Firestore = getFirestore(app);
const analyticsInstance: Analytics = _getAnalytics(app);

// Resolve the promise immediately after initialization
if (resolveFirebaseReady) {
    console.log("Firebase modular SDK initialized. Resolving firebaseInitializedPromise.");
    resolveFirebaseReady();
}

// Export functions to be used by other modules
export function getAuth(): Auth {
    return authInstance;
}

export function getDb(): Firestore {
    return dbInstance;
}

export function getAnalytics(): Analytics {
    return analyticsInstance;
}

// Provide FieldValue methods via a getter function to mimic the v8 behavior
export function getFieldValue() {
    return {
        serverTimestamp: _serverTimestamp,
        increment: _increment,
        delete: _deleteField,
    };
}

// Export the Timestamp class/constructor
export function getTimestamp(): typeof Timestamp {
    return Timestamp;
}

// Export modular Firestore functions directly
export const collection = _collection;
export const doc = _doc;
export const query = _query;
export const where = _where;
export const orderBy = _orderBy;
export const limit = _limit;
export const onSnapshot = _onSnapshot;
export const addDoc = _addDoc;
export const getDoc = _getDoc;
export const getDocs = _getDocs;
export const setDoc = _setDoc;
export const updateDoc = _updateDoc;
export const deleteDoc = _deleteDoc;
export const runTransaction = _runTransaction;
export const writeBatch = _writeBatch;
// FIX: Export modular updateProfile and sendEmailVerification
export const updateProfile = _updateProfile;
