
import React, { useState, useCallback, useEffect, useMemo, useRef } from 'react';
import { Job, Submission, SubmissionStatus, Transaction, TransactionType, Notification, NotificationType, Platform, JobApprovalStatus, Announcement, Message, Deposit } from './types';
import Header from './components/Header';
import CreateJobModal from './components/CreateJobModal';
import ConfirmationModal from './components/ConfirmationModal';
import Wallet from './components/Wallet';
import ManageGigs from './components/ManageGigs';
import EditJobModal from './components/EditJobModal';
import RejectionModal from './components/RejectionModal';
import ReportModal from './components/ReportModal';
import Profile from './components/Profile';
import Auth from './components/Auth';
import { getAuth, getDb, getFieldValue, getTimestamp, collection, doc, query, where, orderBy, limit, onSnapshot, addDoc, getDoc, getDocs, setDoc, updateDoc, deleteDoc, runTransaction, writeBatch, updateProfile } from './firebase';
import { User } from 'firebase/auth'; // Import User type from firebase/auth
import { useToasts } from './components/Toasts';
import AddQuantityModal from './components/AddQuantityModal';
import BoostConfirmationModal from './components/BoostConfirmationModal';
import NotificationsPanel from './components/NotificationsPanel';
// FIX: Changed import to use default export.
import DeleteConfirmationModal from './components/DeleteConfirmationModal';
import FilterModal from './components/FilterModal';
import TipModal from './components/TipModal';
import AnnouncementModal from './components/AnnouncementModal';
import TokenListing from './components/TokenListing';
import Announcements from './components/Announcements';
import Refer from './components/Refer';
import EditProfileModal from './components/EditProfileModal';
import AiAssistantModal from './components/AiAssistantModal';
import { Chat } from '@google/genai';
// FIX: Added missing import for JobCard component.
import JobCard from './components/JobCard';


// MOCK USER IDs (string)
const MOCK_USER_2 = 'mock-user-2-other';
// Removed: ADMIN_UIDS

// For simulation purposes
// UPDATED: Referral codes are now 5 characters long.
const MOCK_REFERRAL_CODES: { [code: string]: string } = {
    'FRIEN': MOCK_USER_2,
    'WELCO': 'mock-user-3',
};

// Helper to prevent floating point inaccuracies in Firestore
const roundCurrency = (num: number): number => {
    return parseFloat(num.toFixed(4));
};

// Helper to find user ref by UID or display name (case-insensitive fallback)
const findUserRef = async (identifier: string): Promise<any | null> => {
    if (!identifier) return null;
    
    // 1. Try as UID first
    const userDocRef = doc(collection(getDb(), 'users'), identifier);
    const userDocSnap = await getDoc(userDocRef);
    if (userDocSnap.exists()) {
        return userDocRef;
    }
    
    // 2. Fallback to display name with case variations
    const name = identifier;
    const namesToQuery = [...new Set([
        name, 
        name.toLowerCase(), 
        name.toUpperCase(),
        name.charAt(0).toUpperCase() + name.slice(1).toLowerCase()
    ])];
    
    for (const nameCase of namesToQuery) {
        const usersQueryRef = query(collection(getDb(), 'users'), where('displayName', '==', nameCase), limit(1));
        const usersQuerySnap = await getDocs(usersQueryRef);
        if (!usersQuerySnap.empty) {
            return usersQuerySnap.docs[0].ref;
        }
    }
    
    // 3. If not found, return null
    return null;
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [permissionError, setPermissionError] = useState(false);
  const [errorMessages, setErrorMessages] = useState<string[]>([]);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [submissionsMap, setSubmissionsMap] = useState<Record<string, Submission>>({});
  const [hiddenJobIds, setHiddenJobIds] = useState<number[]>(() => {
    try {
        const saved = localStorage.getItem('hiddenJobIds');
        return saved ? JSON.parse(saved) : [];
    } catch (error) {
        console.error("Failed to parse hiddenJobIds from localStorage", error);
        return [];
    }
  });
  
  useEffect(() => {
    try {
        localStorage.setItem('hiddenJobIds', JSON.stringify(hiddenJobIds));
    } catch (error) {
        console.error("Failed to save hiddenJobIds to localStorage", error);
    }
  }, [hiddenJobIds]);

  // --- Currency State ---
  const [userPoints, setUserPoints] = useState(0); // This is JD TOKENS
  const [userBdtBalance, setUserBdtBalance] = useState(0);

  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [view, setView] = useState<'jobs' | 'announcements' | 'wallet' | 'manage' | 'refer' | 'profile' | 'token'>('jobs');
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isNotificationsPanelOpen, setIsNotificationsPanelOpen] = useState(false);

  // --- Profile State ---
  const [displayName, setDisplayName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [createdAt, setCreatedAt] = useState<string>('');
  const [gigsCompleted, setGigsCompleted] = useState(0);
  const [gigsCreated, setGigsCreated] = useState(0);
  // --- Currency Earnings State ---
  const [totalEarnings, setTotalEarnings] = useState(0); // JD TOKENS earnings
  const [totalBdtEarnings, setTotalBdtEarnings] = useState(0);

  // --- Referral System State ---
  const [userReferralCode, setUserReferralCode] = useState<string>('');
  const [referredBy, setReferredBy] = useState<string | null>(null);
  const [referralsCount, setReferralsCount] = useState<number>(0);
  // --- Currency Unclaimed Referral Earnings State ---
  const [unclaimedReferralEarnings, setUnclaimedReferralEarnings] = useState(0); // JD TOKENS
  const [unclaimedBdtReferralEarnings, setUnclaimedBdtReferralEarnings] = useState(0); // BDT


  // Modal States
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isAddQuantityModalOpen, setIsAddQuantityModalOpen] = useState(false);
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);
  const [isConfirmationModalOpen, setIsConfirmationModalOpen] = useState(false);
  const [isRejectionModalOpen, setIsRejectionModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isBoostModalOpen, setIsBoostModalOpen] = useState(false);
  const [isTipModalOpen, setIsTipModalOpen] = useState(false);
  const [isEditProfileModalOpen, setIsEditProfileModalOpen] = useState(false);
  const [jobToConfirm, setJobToConfirm] = useState<Job | null>(null);
  const [jobToEdit, setJobToEdit] = useState<Job | null>(null);
  const [jobToBoost, setJobToBoost] = useState<Job | null>(null);
  const [jobToAddQuantity, setJobToAddQuantity] = useState<Job | null>(null);
  const [jobToDelete, setJobToDelete] = useState<Job | null>(null);
  const [submissionToReject, setSubmissionToReject] = useState<Submission | null>(null);
  const [submissionToReport, setSubmissionToReport] = useState<Submission | null>(null);
  const [submissionToTip, setSubmissionToTip] = useState<Submission | null>(null);
  
  // Filtering State
  const [selectedCategories, setSelectedCategories] = useState<Platform[]>([]);

  // Announcement State
  const [latestAnnouncement, setLatestAnnouncement] = useState<Announcement | null>(null);
  const [allAnnouncements, setAllAnnouncements] = useState<Announcement[]>([]);
  const [isAnnouncementModalOpen, setIsAnnouncementModalOpen] = useState(false);

  // --- AI Assistant State ---
  const [isAiAssistantModalOpen, setIsAiAssistantModal] = useState(false);
  const [aiMessages, setAiMessages] = useState<Message[]>([]);
  const chatSessionRef = useRef<Chat | null>(null);
  const [aiLanguage, setAiLanguage] = useState<'en' | 'bn' | null>(null);

  const { addToast } = useToasts();

  const allSubmissions = useMemo(() => Object.values(submissionsMap), [submissionsMap]);
  const userSubmissions = useMemo(() => allSubmissions.filter(s => s.userId === user?.uid), [allSubmissions, user]);
  const postedJobs = useMemo(() => jobs.filter(job => job.posterId === user?.uid), [jobs, user]);

  const onSetAiLanguage = useCallback((lang: 'en' | 'bn') => {
    setAiLanguage(lang);
    setAiMessages([]);
    chatSessionRef.current = null; // Force re-initialization with new language
  }, [setAiMessages]);

  // --- Auth & Initial User Document Setup ---
  useEffect(() => {
    const unsubscribeAuth = getAuth().onAuthStateChanged(async (user) => {
      if (user) {
        setUser(user);
        setPermissionError(false);
        setErrorMessages([]);
        
        const userRef = doc(collection(getDb(), 'users'), user.uid);
        const userDocSnap = await getDoc(userRef);

        if (!userDocSnap.exists()) {
            console.log("New user detected, setting up account...");

            const referralCode = Math.random().toString(36).substring(2, 7).toUpperCase();
            const displayName = `user${user.uid.substring(0, 5)}`;
            await updateProfile(user, { displayName });

            const referralCodeUsed = sessionStorage.getItem('referralCode');
            sessionStorage.removeItem('referralCode');
            let referredByUID: string | null = null;
            if (referralCodeUsed && MOCK_REFERRAL_CODES[referralCodeUsed]) {
                referredByUID = MOCK_REFERRAL_CODES[referralCodeUsed];
            } else if (referralCodeUsed) {
                 const codesQueryRef = query(collection(getDb(), 'users'), where('referralCode', '==', referralCodeUsed), limit(1));
                 const codesQuerySnap = await getDocs(codesQueryRef);
                 if (!codesQuerySnap.empty) {
                     referredByUID = codesQuerySnap.docs[0].id;
                 }
            }
            
            // Initial set up for new user (default values, will be incremented if referred)
            await setDoc(userRef, {
                displayName: displayName,
                email: user.email,
                photoURL: user.photoURL,
                createdAt: getFieldValue().serverTimestamp(),
                referralCode: referralCode,
                referredBy: referredByUID,
                gigsCompleted: 0,
                gigsCreated: 0,
                totalEarnings: 0, 
                totalBdtEarnings: 0,
                unclaimedReferralEarnings: 0,
                unclaimedBdtReferralEarnings: 0,
                referralsCount: 0,
            });
            
            const walletRef = doc(collection(getDb(), 'wallets'), user.uid);
            await setDoc(walletRef, {
                points: 0, 
                bdtBalance: 0 
            });

            const batch = writeBatch(getDb());

            if (referredByUID) {
                const referredByUserRef = doc(collection(getDb(), 'users'), referredByUID);
                
                // 1. Referrer gets 5 JD TOKENS (unclaimed)
                batch.update(referredByUserRef, {
                    referralsCount: getFieldValue().increment(1),
                    unclaimedReferralEarnings: getFieldValue().increment(5),
                });
                
                // 2. New user gets 5 JD TOKENS directly to wallet and total earnings
                batch.update(walletRef, { points: getFieldValue().increment(5) });
                batch.update(userRef, { totalEarnings: getFieldValue().increment(5) });

                // 3. Add transaction for new user's bonus
                const newUserTransactionRef = doc(collection(userRef, 'transactions'));
                batch.set(newUserTransactionRef, {
                    type: TransactionType.REFERRAL_SIGNUP_BONUS,
                    amount: 5,
                    currency: 'JD TOKENS',
                    description: `Referral signup bonus for using code ${referralCodeUsed}`,
                    date: getFieldValue().serverTimestamp(),
                });

                addToast('রেফার কোড ব্যবহার করে সাইন আপ করার জন্য আপনি 5 JD TOKENS বোনাস পেয়েছেন! আপনার রেফারারও 5 JD TOKENS পেয়েছেন।', 'success');
            } else {
                addToast('JobDella-তে আপনাকে স্বাগতম!', 'success');
            }
            
            await batch.commit();

        } else {
            // --- One-time data migration/initialization for EXISTING users ---
            const userDocData = userDocSnap.data(); // Get user document data
            const walletRef = doc(collection(getDb(), 'wallets'), user.uid);
            const walletDocSnap = await getDoc(walletRef);
            
            const batch = writeBatch(getDb());
            let userUpdateNeeded = false;
            const userUpdate: { [key: string]: any } = {};

            if (!user.displayName && !userDocData?.displayName) {
                const defaultDisplayName = `user${user.uid.substring(0, 5)}`;
                await updateProfile(user, { displayName: defaultDisplayName });
                userUpdate.displayName = defaultDisplayName;
                userUpdateNeeded = true;
            } else if (!userDocData?.displayName && user.displayName) {
                 userUpdate.displayName = user.displayName;
                 userUpdateNeeded = true;
            }

            if (userDocData?.createdAt === undefined) { userUpdate.createdAt = getFieldValue().serverTimestamp(); userUpdateNeeded = true; }
            if (userDocData?.referralCode === undefined) { userUpdate.referralCode = Math.random().toString(36).substring(2, 7).toUpperCase(); userUpdateNeeded = true; }
            if (userDocData?.referredBy === undefined) { userUpdate.referredBy = null; userUpdateNeeded = true; }
            if (userDocData?.gigsCompleted === undefined) { userUpdate.gigsCompleted = 0; userUpdateNeeded = true; }
            if (userDocData?.gigsCreated === undefined) { userUpdate.gigsCreated = 0; userUpdateNeeded = true; }
            if (userDocData?.totalEarnings === undefined) { userUpdate.totalEarnings = 0; userUpdateNeeded = true; }
            if (userDocData?.totalBdtEarnings === undefined) { userUpdate.totalBdtEarnings = 0; userUpdateNeeded = true; }
            if (userDocData?.unclaimedReferralEarnings === undefined) { userUpdate.unclaimedReferralEarnings = 0; userUpdateNeeded = true; }
            if (userDocData?.unclaimedBdtReferralEarnings === undefined) { userUpdate.unclaimedBdtReferralEarnings = 0; userUpdateNeeded = true; }
            if (userDocData?.referralsCount === undefined) { userUpdate.referralsCount = 0; userUpdateNeeded = true; }


            if (userUpdateNeeded) {
                batch.update(userRef, userUpdate);
            }

            if (!walletDocSnap.exists()) {
                console.log("Wallet document not found for existing user. Migrating balances...");
                
                const bdtBalance = userDocData?.bdtBalance ?? 0;
                const jdTokens = userDocData?.points ?? userDocData?.balance ?? 0;

                batch.set(walletRef, {
                    points: jdTokens,
                    bdtBalance: bdtBalance
                });

                const userBalanceCleanup: { [key: string]: any } = {};
                if (userDocData?.hasOwnProperty('bdtBalance')) userBalanceCleanup.bdtBalance = getFieldValue().delete();
                if (userDocData?.hasOwnProperty('points')) userBalanceCleanup.points = getFieldValue().delete();
                if (userDocData?.hasOwnProperty('balance')) userBalanceCleanup.balance = getFieldValue().delete();
                
                if (Object.keys(userBalanceCleanup).length > 0) {
                    batch.update(userRef, userBalanceCleanup);
                }
            }

            if (userUpdateNeeded || !walletDocSnap.exists()) {
                try {
                    await batch.commit();
                    addToast('Your account has been updated for full compatibility.', 'info');
                } catch (migrationError) {
                    console.error("Failed to migrate/update existing user data:", migrationError);
                    addToast('Could not update your account. Please contact support.', 'error');
                }
            }
        }
        setLoading(false); // Stop loading after initial user setup/migration
      } else {
        setUser(null);
        setLoading(false);
      }
    });

    return () => unsubscribeAuth();
  }, [addToast]);

  // --- Listeners for user-specific data (wallet, profile, tx, notifications) ---
  useEffect(() => {
    // These listeners depend on 'user'
    if (!user) { 
        // Clear sensitive user data if not logged in
        setUserPoints(0);
        setUserBdtBalance(0);
        setDisplayName('');
        setEmail('');
        setCreatedAt('');
        setGigsCompleted(0);
        setGigsCreated(0);
        setTotalEarnings(0);
        setTotalBdtEarnings(0);
        setUserReferralCode('');
        setReferredBy(null);
        setReferralsCount(0);
        setUnclaimedReferralEarnings(0);
        setUnclaimedBdtReferralEarnings(0);
        setTransactions([]);
        setNotifications([]);
        return; // Do not attach listeners
    }

    const userRef = doc(collection(getDb(), 'users'), user.uid);
    const listeners: (() => void)[] = [];

    listeners.push(
      onSnapshot(doc(collection(getDb(), 'wallets'), user.uid), docSnap => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          setUserPoints(data?.points || 0);
          setUserBdtBalance(data?.bdtBalance || 0);
        } else {
          setUserPoints(0);
          setUserBdtBalance(0);
        }
      }, err => {
          const errorMessage = "Could not load wallet data due to a permissions issue.";
          console.error("Error fetching wallet:", err);
          if (err.message?.includes('permission')) {
            setPermissionError(true);
            setErrorMessages(prev => [...new Set([...prev, errorMessage])]);
          } else {
            addToast("Could not load your wallet data.", "error");
          }
          setUserPoints(0);
          setUserBdtBalance(0);
      })
    );
    listeners.push(
      onSnapshot(userRef, docSnap => {
        if (docSnap.exists()) {
            const data = docSnap.data();
            setDisplayName(data?.displayName || '');
            setEmail(data?.email || '');
            setCreatedAt(data?.createdAt?.toDate().toLocaleDateString() || '');
            setGigsCompleted(data?.gigsCompleted || 0);
            setGigsCreated(data?.gigsCreated || 0);
            setTotalEarnings(data?.totalEarnings || 0);
            setTotalBdtEarnings(data?.totalBdtEarnings || 0);
            setUserReferralCode(data?.referralCode || '');
            setReferredBy(data?.referredBy || null);
            setReferralsCount(data?.referralsCount || 0);
            setUnclaimedReferralEarnings(data?.unclaimedReferralEarnings || 0);
            setUnclaimedBdtReferralEarnings(data?.unclaimedBdtReferralEarnings || 0);
        }
      }, err => {
          const errorMessage = "Could not load your profile due to a permissions issue.";
          console.error("Error fetching user profile:", err);
          if (err.message?.includes('permission')) {
            setPermissionError(true);
             setErrorMessages(prev => [...new Set([...prev, errorMessage])]);
          } else {
            addToast("Could not load your profile information.", "error");
          }
          setDisplayName('');
          setEmail('');
          setCreatedAt('');
          setGigsCompleted(0);
          setGigsCreated(0);
      })
    );
    listeners.push(
      onSnapshot(query(collection(userRef, 'transactions'), orderBy('date', 'desc')), snapshot => {
        const txs = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
          date: doc.data().date?.toDate() || new Date(),
        } as Transaction));
        setTransactions(txs);
      }, err => {
          const errorMessage = "Could not load transaction history due to a permissions issue.";
          console.error("Error fetching transactions:", err);
           if (err.message?.includes('permission')) {
            setPermissionError(true);
             setErrorMessages(prev => [...new Set([...prev, errorMessage])]);
          } else {
            addToast("Could not load your transaction history.", "error");
          }
          setTransactions([]);
      })
    );
    listeners.push(
      onSnapshot(query(collection(userRef, 'notifications'), orderBy('createdAt', 'desc')), snapshot => {
         const notifs = snapshot.docs.map(doc => ({
             id: doc.id,
             ...doc.data()
         } as Notification));
         setNotifications(notifs);
      }, err => {
          const errorMessage = "Could not load notifications due to a permissions issue.";
          console.error("Error fetching notifications:", err);
           if (err.message?.includes('permission')) {
            setPermissionError(true);
            setErrorMessages(prev => [...new Set([...prev, errorMessage])]);
          } else {
            addToast("Could not load your notifications.", "error");
          }
          setNotifications([]);
      })
    );
    
    return () => listeners.forEach(unsubscribe => unsubscribe());
  }, [user, addToast]); 

  // --- Global Data Loading (Jobs) ---
  useEffect(() => {
    if (!user) { 
      setJobs([]); 
      // Clear submissions related to jobs only if user is logged out
      setSubmissionsMap({}); // Clear submissions as they are usually tied to job data
      return;
    }
    const jobsCollectionRef = collection(getDb(), 'jobs');
    const q = query(jobsCollectionRef, orderBy('createdAt', 'desc'));
    const unsubscribeJobs = onSnapshot(q, snapshot => {
      const jobsData = snapshot.docs.map(doc => ({
        id: parseInt(doc.id, 10),
        ...doc.data(),
      } as Job));
      setJobs(jobsData);
    }, err => {
        const errorMessage = "Could not load jobs due to a permissions issue.";
        console.error("Error fetching jobs:", err);
        if (err.message?.includes('permission')) {
            setPermissionError(true);
            setErrorMessages(prev => [...new Set([...prev, errorMessage])]);
        }
        addToast(errorMessage, "error");
        setJobs([]);
    });

    return () => {
      unsubscribeJobs();
    };
  }, [user, addToast]); 

  // --- User-Specific Submissions Loading ---
  useEffect(() => {
      if (!user) { 
          setSubmissionsMap({}); // Clear all submissions on logout
          return;
      }

      const submissionsCollectionRef = collection(getDb(), 'submissions');
      const q = query(submissionsCollectionRef, where('userId', '==', user.uid));
      const unsubscribeUserSubmissions = onSnapshot(q, snapshot => {
              const userSubs: Record<string, Submission> = {};
              snapshot.forEach(docSnap => {
                  userSubs[docSnap.id] = { id: docSnap.id, ...docSnap.data() } as Submission;
              });
              setSubmissionsMap(prev => ({...prev, ...userSubs}));
          }, err => {
              const errorMessage = "Could not load your submissions due to a permissions issue.";
              console.error("Error listening to user submissions:", err);
               if (err.message?.includes('permission')) {
                setPermissionError(true);
                setErrorMessages(prev => [...new Set([...prev, errorMessage])]);
              }
              addToast('Error loading your submissions.', 'error');
          });

      return () => {
          unsubscribeUserSubmissions();
      };
  }, [user, addToast]); 

  // --- Poster-Specific Submissions Loading ---
  useEffect(() => {
      if (!user) return; 

      if (postedJobs.length === 0) {
          // If the user has no jobs, clear any lingering poster submissions from a previous state
          setSubmissionsMap(prev => {
              const userSubs = Object.fromEntries(Object.entries(prev).filter(([_, sub]) => (sub as Submission).userId === user.uid));
              return userSubs;
          });
          return;
      }

      const unsubscribers: (() => void)[] = [];
      const postedJobIdsArray = postedJobs.map(job => job.id); 

      // Listener for submissions TO jobs posted by the user
      // Batched in chunks of 30 for Firestore 'in' query limit
      for (let i = 0; i < postedJobIdsArray.length; i += 30) {
          const chunk = postedJobIdsArray.slice(i, i + 30); 
          const submissionsCollectionRef = collection(getDb(), 'submissions');
          const q = query(submissionsCollectionRef, where('jobId', 'in', chunk));
          const posterSubmissionsListener = onSnapshot(q, snapshot => {
                  const posterSubs: Record<string, Submission> = {};
                  snapshot.forEach(docSnap => {
                      posterSubs[docSnap.id] = { id: docSnap.id, ...docSnap.data() } as Submission;
                  });
                  setSubmissionsMap(prev => ({...prev, ...posterSubs}));
              }, err => {
                  const errorMessage = "Could not load gig submissions due to a permissions issue.";
                  console.error("Error listening to poster submissions:", err);
                   if (err.message?.includes('permission')) {
                    setPermissionError(true);
                    setErrorMessages(prev => [...new Set([...prev, errorMessage])]);
                  }
                  addToast('Error loading gig submissions.', 'error');
              });
          unsubscribers.push(posterSubmissionsListener);
      }
      
      return () => {
          unsubscribers.forEach(unsub => unsub());
      };
  }, [user, postedJobs, addToast]); 

  // --- Announcement Loading ---
  useEffect(() => {
    if (!user) return; 
    const announcementsCollectionRef = collection(getDb(), 'announcements');
    const q = query(announcementsCollectionRef, orderBy('createdAt', 'desc'), limit(5));

    const unsubscribe = onSnapshot(q, snapshot => {
        const latestActiveAnnouncement = snapshot.docs
            .map(doc => ({ id: doc.id, ...doc.data() } as Announcement))
            .find(ann => ann.isActive === true);

        if (latestActiveAnnouncement) {
            setLatestAnnouncement(latestActiveAnnouncement);
            const hasSeen = localStorage.getItem(`seenAnnouncement_${latestActiveAnnouncement.id}`);
            if (!hasSeen) {
                setIsAnnouncementModalOpen(true);
            }
        } else {
            setLatestAnnouncement(null);
        }
      }, err => {
        const errorMessage = "Could not load announcements due to a permissions issue.";
        console.error("Error fetching announcements:", err);
        if (err.message?.includes('permission')) {
          setPermissionError(true);
          setErrorMessages(prev => [...new Set([...prev, errorMessage])]);
        } else {
          addToast("Could not load announcements.", "error");
        }
      });

    return () => unsubscribe();
}, [user, addToast]); 

  // --- All Announcements Loading ---
  useEffect(() => {
    if (!user) return; 
    const announcementsCollectionRef = collection(getDb(), 'announcements');
    const q = query(announcementsCollectionRef, orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, snapshot => {
        const announcementsData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Announcement));
        setAllAnnouncements(announcementsData);
      }, err => {
        const errorMessage = "Could not load announcements list due to a permissions issue.";
        console.error("Error fetching all announcements:", err);
        if (err.message?.includes('permission')) {
          setPermissionError(true);
          setErrorMessages(prev => [...new Set([...prev, errorMessage])]);
        } else {
          addToast("Could not load announcements list.", "error");
        }
      });

    return () => unsubscribe();
  }, [user, addToast]); 

  // --- Referral Commission for Deposits ---
  useEffect(() => {
    if (!user) return; // Only run if user is logged in

    const depositsCollectionRef = collection(getDb(), 'deposits');
    const q = query(
        depositsCollectionRef,
        where('status', '==', 'APPROVED'),
        where('referrerBonusProcessed', '!=', true) // Only process if not already processed
    );

    const unsubscribeDeposits = onSnapshot(q, async (snapshot) => {
        for (const docChange of snapshot.docChanges()) {
            if (docChange.type === 'added' || docChange.type === 'modified') {
                const deposit = { id: docChange.doc.id, ...docChange.doc.data() } as Deposit;

                // Ensure it's approved and not yet processed for referrer bonus
                if (deposit.status === 'APPROVED' && !deposit.referrerBonusProcessed) {
                    console.log(`Processing referrer bonus for approved deposit: ${deposit.id}`);

                    try {
                        await runTransaction(getDb(), async (transaction) => {
                            const depositorRef = doc(collection(getDb(), 'users'), deposit.userId);
                            const depositorDoc = await transaction.get(depositorRef);

                            if (!depositorDoc.exists()) {
                                console.warn(`Depositor user ${deposit.userId} not found for deposit ${deposit.id}`);
                                return; // Skip if depositor not found
                            }
                            const depositorData = depositorDoc.data();
                            const referredByUID = depositorData?.referredBy;

                            if (referredByUID) {
                                const referrerUserRef = doc(collection(getDb(), 'users'), referredByUID);
                                const referrerUserDoc = await transaction.get(referrerUserRef);

                                if (referrerUserDoc.exists()) {
                                    const commissionAmount = roundCurrency(deposit.amount * 0.05); // 5% of deposit
                                    if (commissionAmount > 0) {
                                        transaction.update(referrerUserRef, {
                                            unclaimedBdtReferralEarnings: getFieldValue().increment(commissionAmount)
                                        });

                                        // Add notification for referrer
                                        const notificationRef = doc(collection(referrerUserRef, 'notifications'));
                                        transaction.set(notificationRef, {
                                            userId: referrerUserRef.id,
                                            type: NotificationType.REFERRAL_COMMISSION, 
                                            message: `You earned ${commissionAmount.toFixed(2)} BDT commission from your referral's deposit!`,
                                            isRead: false,
                                            createdAt: getFieldValue().serverTimestamp(),
                                        });

                                        // Add transaction for referrer
                                        const referrerTransactionRef = doc(collection(referrerUserRef, 'transactions'));
                                        transaction.set(referrerTransactionRef, {
                                            type: TransactionType.REFERRAL_COMMISSION, 
                                            amount: commissionAmount,
                                            currency: 'BDT',
                                            description: `Referral commission from user ${depositorData.displayName || deposit.userId}'s deposit`,
                                            date: getFieldValue().serverTimestamp(),
                                        });
                                        console.log(`Referrer ${referredByUID} awarded ${commissionAmount} BDT for deposit ${deposit.id}`);
                                    }
                                } else {
                                    console.warn(`Referrer user ${referredByUID} not found for deposit ${deposit.id}`);
                                }
                            }

                            // Mark deposit as processed for referrer bonus to prevent re-processing
                            const depositRef = doc(collection(getDb(), 'deposits'), deposit.id);
                            transaction.update(depositRef, { referrerBonusProcessed: true });
                        });
                    } catch (error) {
                        console.error(`Transaction failed for referrer bonus on deposit ${deposit.id}:`, error);
                        addToast(`Failed to process referral bonus for deposit ${deposit.id}. Please contact support.`, 'error');
                    }
                }
            }
        }
    }, err => {
        console.error("Error listening to approved deposits for referrer bonus:", err);
        addToast("Error loading deposit data for referral bonuses.", "error");
    });

    return () => unsubscribeDeposits();
}, [user, addToast]);


  const handleNavClick = (newView: 'jobs' | 'announcements' | 'wallet' | 'manage' | 'refer' | 'profile' | 'token') => {
    setView(newView);
  };
  
  // --- Job & Submission Actions ---
  const handleAddJob = async (jobData: Omit<Job, 'id' | 'posterId' | 'remaining' | 'createdAt' | 'boostedUntil' | 'approvalStatus' | 'rejectionReason'>) => {
    if (!user) {
        addToast('You must be logged in to post a job.', 'error');
        throw new Error('User not logged in');
    }

    const { reward, quantity, currency } = jobData;
    const baseCost = reward * quantity;
    const platformFee = baseCost * 0.10;
    const totalCost = roundCurrency(baseCost + platformFee);

    const userBalance = currency === 'BDT' ? userBdtBalance : userPoints;

    if (userBalance < totalCost) {
      addToast('Insufficient funds to post this job.', 'error');
      throw new Error('Insufficient funds');
    }
    
    const batch = writeBatch(getDb());
    const userRef = doc(collection(getDb(), 'users'), user.uid);
    const walletRef = doc(collection(getDb(), 'wallets'), user.uid);
    
    const counterRef = doc(collection(getDb(), 'counters'), 'jobs');
    let newJobId: number;

    try {
        await runTransaction(getDb(), async (transaction) => {
            const counterDoc = await transaction.get(counterRef);
            if (!counterDoc.exists()) {
                transaction.set(counterRef, { count: 1 });
                newJobId = 1;
            } else {
                newJobId = counterDoc.data()!.count + 1;
                transaction.update(counterRef, { count: newJobId });
            }
        });
    } catch (error) {
        console.error("Error getting new job ID:", error);
        addToast("Could not generate a job ID. Please try again.", "error");
        throw new Error("Could not generate job ID");
    }

    const newJobRef = doc(collection(getDb(), 'jobs'), newJobId!.toString());
    
    const newJobData = { ...jobData };
    if (!newJobData.subcategory) {
        delete (newJobData as Partial<typeof newJobData>).subcategory;
    }
    if (!newJobData.twitterSubcategory) {
        delete (newJobData as Partial<typeof newJobData>).twitterSubcategory;
    }
    
    const newJob: Job = {
      id: newJobId!,
      posterId: user.uid,
      ...newJobData,
      remaining: quantity,
      pendingCount: 0,
      createdAt: getFieldValue().serverTimestamp(),
      approvalStatus: JobApprovalStatus.APPROVED, 
    };
    batch.set(newJobRef, newJob);

    const balanceField = currency === 'BDT' ? 'bdtBalance' : 'points';
    batch.update(walletRef, { [balanceField]: getFieldValue().increment(-totalCost) });

    const transactionRef = doc(collection(userRef, 'transactions'));
    batch.set(transactionRef, {
      type: TransactionType.GIG_POST,
      amount: -totalCost,
      currency,
      description: `Posted job: "${jobData.title}" (ID: ${newJobId})`,
      date: getFieldValue().serverTimestamp(),
    });

    batch.update(userRef, { gigsCreated: getFieldValue().increment(1) });
    
    // Referrer Commission Logic (1% of poster's job cost in BDT)
    if (referredBy) {
        const referredByUserRef = await findUserRef(referredBy);
        if (referredByUserRef) {
            const commissionableAmountBdt = currency === 'BDT' ? totalCost : totalCost / 10; // Assuming 10 JDT = 1 BDT for this calculation
            const commissionBdt = roundCurrency(commissionableAmountBdt * 0.01); // This is 1%
            if (commissionBdt > 0) {
                batch.update(referredByUserRef, {
                    unclaimedBdtReferralEarnings: getFieldValue().increment(commissionBdt)
                });
                
                const notificationRef = doc(collection(referredByUserRef, 'notifications'));
                batch.set(notificationRef, {
                    userId: referredByUserRef.id,
                    type: NotificationType.REFERRAL_GIG_POST_COMMISSION,
                    message: `You earned ${commissionBdt.toFixed(2)} BDT commission because your referral posted a job!`,
                    isRead: false,
                    createdAt: getFieldValue().serverTimestamp(),
                });
            }
        }
    }


    try {
        await batch.commit();
        addToast('Job posted successfully!', 'success');
        setIsCreateModalOpen(false);
    } catch (error) {
        console.error("Error posting job:", error);
        addToast('Failed to post job. Please try again.', 'error');
        throw error;
    }
  };

  const handleClaimJob = (job: Job) => {
    setJobToConfirm(job);
    setIsConfirmationModalOpen(true);
  };
  
  const handleHideJob = (jobId: number) => {
    setHiddenJobIds(prev => [...prev, jobId]);
    addToast('Job hidden. It will not be shown again.', 'info');
  };

  const handleConfirmSubmission = async (jobId: number, proof: string) => {
    if (!user) {
        addToast('You must be logged in.', 'error');
        return;
    }

    const job = jobs.find(j => j.id === jobId);
    if (!job) {
        addToast('Job not found.', 'error');
        return;
    }
    
    let userIpAddress = 'N/A';
    try {
        const response = await fetch('https://api64.ipify.org?format=json');
        if (response.ok) {
            const data = await response.json();
            userIpAddress = data.ip;
        } else {
            console.warn('Could not fetch user IP from ipify.');
        }
    } catch (error) {
        console.error('Error fetching user IP:', error);
    }

    const submission: Omit<Submission, 'id'> = {
      userId: user.uid,
      userDisplayName: user.displayName || `user-${user.uid.substring(0,5)}`,
      userIp: userIpAddress,
      jobId,
      jobTitle: job.title,
      proof,
      status: SubmissionStatus.PENDING,
      createdAt: getFieldValue().serverTimestamp(),
    };
    
    const batch = writeBatch(getDb());
    const submissionRef = doc(collection(getDb(), 'submissions'));
    const jobRef = doc(collection(getDb(), 'jobs'), jobId.toString());
    
    batch.set(submissionRef, submission);
    batch.update(jobRef, { 
        remaining: getFieldValue().increment(-1),
        pendingCount: getFieldValue().increment(1)
    });

    try {
        await batch.commit();
        addToast('Submission received! It will be reviewed by the job poster.', 'success');
        setIsConfirmationModalOpen(false);
    } catch (error) {
        console.error("Error submitting proof:", error);
        addToast('Failed to submit. Please try again.', 'error');
    }
  };
  
  const handleEditJob = async (job: Job) => {
      const jobRef = doc(collection(getDb(), 'jobs'), job.id.toString());
      try {
          await updateDoc(jobRef, {
              title: job.title,
              task: job.task,
          });
          addToast('Job updated successfully!', 'success');
          setIsEditModalOpen(false);
      } catch (error) {
          console.error("Error updating job:", error);
          addToast('Failed to update job.', 'error');
      }
  };

  const handleApproveSubmission = useCallback(async (submissionId: string) => {
    if (!user) return;

    const submission = submissionsMap[submissionId];
    if (!submission || submission.status !== SubmissionStatus.PENDING) {
        console.warn(`Submission ${submissionId} already processed or not found.`);
        return;
    }

    const job = jobs.find(j => j.id === submission.jobId);
    if (!job) {
        console.error(`Job ${submission.jobId} not found for submission ${submissionId}`);
        return;
    }

    const batch = writeBatch(getDb());
    const submissionRef = doc(collection(getDb(), 'submissions'), submissionId);
    const jobRef = doc(collection(getDb(), 'jobs'), submission.jobId.toString());
    const workerRef = doc(collection(getDb(), 'users'), submission.userId);
    const workerWalletRef = doc(collection(getDb(), 'wallets'), submission.userId);

    batch.update(submissionRef, { status: SubmissionStatus.APPROVED });
    batch.update(jobRef, { pendingCount: getFieldValue().increment(-1) });
    const workerBalanceField = job.currency === 'BDT' ? 'bdtBalance' : 'points';
    batch.update(workerWalletRef, { [workerBalanceField]: getFieldValue().increment(job.reward) });
    
    const workerTransactionRef = doc(collection(workerRef, 'transactions'));
    batch.set(workerTransactionRef, {
        type: TransactionType.GIG_COMPLETED,
        amount: job.reward,
        currency: job.currency,
        description: `Completed: "${job.title}"`,
        date: getFieldValue().serverTimestamp(),
    });

    const totalEarningsField = job.currency === 'BDT' ? 'totalBdtEarnings' : 'totalEarnings';
    batch.update(workerRef, { 
        gigsCompleted: getFieldValue().increment(1),
        [totalEarningsField]: getFieldValue().increment(job.reward)
    });
    
    // Referrer Commission Logic (5% of worker's earnings, in job's currency)
    const workerDocSnap = await getDoc(workerRef);
    const workerData = workerDocSnap.data();
    if (workerData?.referredBy) {
        const referrerUserRef = await findUserRef(workerData.referredBy);
        if (referrerUserRef) {
            const commissionAmount = roundCurrency(job.reward * 0.05); // 5% of the job reward
            const commissionCurrency = job.currency;

            if (commissionAmount > 0) {
                if (commissionCurrency === 'JD TOKENS') {
                    batch.update(referrerUserRef, {
                        unclaimedReferralEarnings: getFieldValue().increment(commissionAmount)
                    });
                } else { // BDT
                    batch.update(referrerUserRef, {
                        unclaimedBdtReferralEarnings: getFieldValue().increment(commissionAmount)
                    });
                }
                const notificationRef = doc(collection(referrerUserRef, 'notifications'));
                batch.set(notificationRef, {
                    userId: referrerUserRef.id,
                    type: NotificationType.EARNINGS_COMMISSION,
                    message: `You earned ${commissionAmount.toFixed(2)} ${commissionCurrency} commission from your referral's earnings!`,
                    isRead: false,
                    createdAt: getFieldValue().serverTimestamp(),
                });
            }
        }
    }

    try {
        await batch.commit();
        addToast('Submission approved and worker paid.', 'success');
    } catch (error) {
        console.error("Error approving submission:", error);
        addToast('Failed to approve submission.', 'error');
    }
  }, [user, jobs, submissionsMap, addToast]); 

  const handleRejectSubmission = async (submissionId: string, reason: string) => {
    const batch = writeBatch(getDb());
    const submissionRef = doc(collection(getDb(), 'submissions'), submissionId);
    const submission = submissionsMap[submissionId];
    if (!submission) return;

    const jobRef = doc(collection(getDb(), 'jobs'), submission.jobId.toString());

    batch.update(submissionRef, { 
        status: SubmissionStatus.REJECTED,
        rejectionReason: reason 
    });
    batch.update(jobRef, {
        remaining: getFieldValue().increment(1),
        pendingCount: getFieldValue().increment(-1)
    });

    try {
        await batch.commit();
        addToast('Submission rejected.', 'info');
        setIsRejectionModalOpen(false);
    } catch (error) {
        console.error("Error rejecting submission:", error);
        addToast('Failed to reject submission.', 'error');
    }
  };
  
    const handleConfirmDelete = async (jobId: number) => {
        if (!user) return;

        const job = jobs.find(j => j.id === jobId);
        if (!job) {
            addToast('Job not found.', 'error');
            return;
        }

        const jobSubmissions = allSubmissions.filter(s => s.jobId === job.id);
        const pendingSubmissions = jobSubmissions.filter(s => s.status === SubmissionStatus.PENDING);

        const batch = writeBatch(getDb());
        const userRef = doc(collection(getDb(), 'users'), user.uid);
        const walletRef = doc(collection(getDb(), 'wallets'), user.uid);
        const jobRef = doc(collection(getDb(), 'jobs'), job.id.toString());
        
        let pendingCost = 0;
        
        for (const sub of pendingSubmissions) {
            const submissionRef = doc(collection(getDb(), 'submissions'), sub.id);
            const workerRef = doc(collection(getDb(), 'users'), sub.userId);
            const workerWalletRef = doc(collection(getDb(), 'wallets'), sub.userId);
            
            batch.update(submissionRef, { status: SubmissionStatus.APPROVED });

            const workerBalanceField = job.currency === 'BDT' ? 'bdtBalance' : 'points';
            batch.update(workerWalletRef, { [workerBalanceField]: getFieldValue().increment(job.reward) });
            pendingCost += job.reward;
            
            const workerTransactionRef = doc(collection(workerRef, 'transactions'));
            batch.set(workerTransactionRef, {
                type: TransactionType.GIG_COMPLETED,
                amount: job.reward,
                currency: job.currency,
                description: `Completed: "${job.title}" (Job Deleted)`,
                date: getFieldValue().serverTimestamp(),
            });

            const totalEarningsField = job.currency === 'BDT' ? 'totalBdtEarnings' : 'totalEarnings';
            batch.update(workerRef, { 
                gigsCompleted: getFieldValue().increment(1),
                [totalEarningsField]: getFieldValue().increment(job.reward)
            });
        }
        
        const baseCostPerTask = job.reward * 1.10; 
        const refundAmount = roundCurrency((job.remaining) * baseCostPerTask);
        
        if (refundAmount > 0) {
            const balanceField = job.currency === 'BDT' ? 'bdtBalance' : 'points';
            batch.update(walletRef, { [balanceField]: getFieldValue().increment(refundAmount) });

            const refundTransactionRef = doc(collection(userRef, 'transactions'));
            batch.set(refundTransactionRef, {
                type: TransactionType.GIG_REFUND,
                amount: refundAmount,
                currency: job.currency,
                description: `Refund for deleted job: "${job.title}"`,
                date: getFieldValue().serverTimestamp(),
            });
        }
        
        batch.delete(jobRef);
        
        try {
            await batch.commit();
            addToast(`Job "${job.title}" deleted successfully.`, 'success');
            setIsDeleteModalOpen(false);
        } catch (error) {
            console.error("Error deleting job:", error);
            addToast('Failed to delete job. Please try again.', 'error');
        }
    };
    
    const handleConfirmBoost = async (duration: number, cost: number) => {
        if (!user || !jobToBoost) return;

        const jobRef = doc(collection(getDb(), 'jobs'), jobToBoost.id.toString());
        const walletRef = doc(collection(getDb(), 'wallets'), user.uid);
        const userRef = doc(collection(getDb(), 'users'), user.uid);
        
        const batch = writeBatch(getDb());
        
        const boostEndTime = new Date(Date.now() + duration * 60 * 1000);
        
        batch.update(jobRef, { boostedUntil: getTimestamp().fromDate(boostEndTime) });
        batch.update(walletRef, { bdtBalance: getFieldValue().increment(-cost) });
        
        const transactionRef = doc(collection(userRef, 'transactions'));
        batch.set(transactionRef, {
            type: TransactionType.GIG_BOOST,
            amount: -cost,
            currency: 'BDT',
            description: `Boosted job: "${jobToBoost.title}" for ${duration} mins`,
            date: getFieldValue().serverTimestamp(),
        });
        
        try {
            await batch.commit();
            addToast('Job boosted successfully!', 'success');
            setIsBoostModalOpen(false);
        } catch (error) {
            console.error("Error boosting job:", error);
            addToast('Failed to boost job. Please try again.', 'error');
            throw error;
        }
    };

    const handleConfirmAddQuantity = async (job: Job, additionalQuantity: number) => {
        if (!user) {
            addToast('You must be logged in.', 'error');
            return;
        }

        const baseCost = job.reward * additionalQuantity;
        const platformFee = baseCost * 0.10;
        const totalCost = roundCurrency(baseCost + platformFee);

        const userBalance = job.currency === 'BDT' ? userBdtBalance : userPoints;
        if (userBalance < totalCost) {
            addToast('Insufficient funds.', 'error');
            return;
        }

        const batch = writeBatch(getDb());
        const jobRef = doc(collection(getDb(), 'jobs'), job.id.toString());
        const walletRef = doc(collection(getDb(), 'wallets'), user.uid);
        const userRef = doc(collection(getDb(), 'users'), user.uid);

        batch.update(jobRef, {
            quantity: getFieldValue().increment(additionalQuantity),
            remaining: getFieldValue().increment(additionalQuantity)
        });

        const balanceField = job.currency === 'BDT' ? 'bdtBalance' : 'points';
        batch.update(walletRef, { [balanceField]: getFieldValue().increment(-totalCost) });

        const transactionRef = doc(collection(userRef, 'transactions'));
        batch.set(transactionRef, {
            type: TransactionType.GIG_ADD_QUANTITY,
            amount: -totalCost,
            currency: job.currency,
            description: `Added ${additionalQuantity} quantity to "${job.title}"`,
            date: getFieldValue().serverTimestamp(),
        });

        try {
            await batch.commit();
            addToast(`Successfully added ${additionalQuantity} to your job!`, 'success');
            setIsAddQuantityModalOpen(false);
        } catch (error) {
            console.error("Error adding quantity:", error);
            addToast('Failed to add quantity. Please try again.', 'error');
        }
    };
    
    const handleReport = async (submissionId: string, reason: string) => {
        try {
            await addDoc(collection(getDb(), 'reports'), {
                submissionId,
                reporterId: user?.uid,
                reason,
                status: 'PENDING',
                createdAt: getFieldValue().serverTimestamp(),
            });
            addToast('Report submitted. An admin will review it.', 'success');
            setIsReportModalOpen(false);
        } catch (error) {
            console.error("Error submitting report:", error);
            addToast('Failed to submit report. Please try again.', 'error');
        }
    };
    
    // --- Wallet Actions ---
    const handleDepositSubmit = async (senderNumber: string, amount: number, transactionId: string) => {
        if (!user) {
            addToast('You must be logged in.', 'error');
            throw new Error('User not logged in');
        }
        try {
            await addDoc(collection(getDb(), 'deposits'), {
                userId: user.uid,
                senderNumber,
                amount,
                transactionId,
                status: 'PENDING',
                createdAt: getFieldValue().serverTimestamp(),
                referrerBonusProcessed: false, // Initialize this flag
            });
            addToast('Deposit request submitted! It will be reviewed shortly.', 'success');
        } catch (error) {
            console.error("Error submitting deposit:", error);
            addToast('Failed to submit deposit request. Please try again.', 'error');
            throw error;
        }
    };
    
    const handleWithdrawalSubmit = async (bKashNumber: string, amount: number) => {
        if (!user) {
            addToast('You must be logged in.', 'error');
            throw new Error('User not logged in');
        }

        if (amount > userBdtBalance) {
            addToast('Withdrawal amount exceeds your BDT balance.', 'error');
            throw new Error('Insufficient funds');
        }

        const batch = writeBatch(getDb());
        const userRef = doc(collection(getDb(), 'users'), user.uid);
        const walletRef = doc(collection(getDb(), 'wallets'), user.uid);
        
        const withdrawalRef = doc(collection(getDb(), 'withdrawals'));
        batch.set(withdrawalRef, {
            userId: user.uid,
            bKashNumber,
            amount,
            status: 'PENDING',
            createdAt: getFieldValue().serverTimestamp(),
        });
        
        batch.update(walletRef, { bdtBalance: getFieldValue().increment(-amount) });
        
        const transactionRef = doc(collection(userRef, 'transactions'));
        batch.set(transactionRef, {
            type: TransactionType.WITHDRAW_REQUEST,
            amount: -amount,
            currency: 'BDT',
            description: `Withdrawal request for ${amount} BDT`,
            date: getFieldValue().serverTimestamp(),
        });
        
        try {
            await batch.commit();
            addToast('Withdrawal request submitted!', 'success');
        } catch (error) {
            console.error("Error submitting withdrawal:", error);
            addToast('Failed to submit withdrawal request. Please try again.', 'error');
            throw error;
        }
    };
    
    // --- Profile/Referral Actions ---
    const handleSaveProfile = async (newName: string, newPhoto: File | null) => {
        if (!user) return;
        
        try {
            const userRef = doc(collection(getDb(), 'users'), user.uid);
            
            await updateProfile(user, { displayName: newName }); 
            await updateDoc(userRef, { displayName: newName });
            
            if (newPhoto) {
                addToast('Profile photo updates are not yet supported.', 'info');
            }
            
            addToast('Profile updated successfully!', 'success');
            setIsEditProfileModalOpen(false);
        } catch (error) {
            console.error("Error updating profile:", error);
            addToast('Failed to update profile.', 'error');
        }
    };

    const handleClaimReferralEarnings = async (currency: 'JD TOKENS' | 'BDT') => {
        if (!user) return;
        
        const isBdt = currency === 'BDT';
        const unclaimedAmount = isBdt ? unclaimedBdtReferralEarnings : unclaimedReferralEarnings;
        
        if (unclaimedAmount <= 0) {
            addToast(`You have no unclaimed ${currency} to collect.`, 'info');
            return;
        }
        
        const batch = writeBatch(getDb());
        const userRef = doc(collection(getDb(), 'users'), user.uid);
        const walletRef = doc(collection(getDb(), 'wallets'), user.uid);
        
        const unclaimedField = isBdt ? 'unclaimedBdtReferralEarnings' : 'unclaimedReferralEarnings';
        const balanceField = isBdt ? 'bdtBalance' : 'points';
        
        batch.update(walletRef, { [balanceField]: getFieldValue().increment(unclaimedAmount) });
        batch.update(userRef, { [unclaimedField]: 0 });
        
        const transactionRef = doc(collection(userRef, 'transactions'));
        batch.set(transactionRef, {
            type: TransactionType.REFERRAL_EARNINGS_CLAIM,
            amount: unclaimedAmount,
            currency,
            description: `Claimed referral earnings`,
            date: getFieldValue().serverTimestamp(),
        });
        
        try {
            await batch.commit();
            addToast(`Successfully claimed ${unclaimedAmount.toFixed(2)} ${currency}!`, 'success');
        } catch (error) {
            console.error("Error claiming earnings:", error);
            addToast('Failed to claim earnings. Please try again.', 'error');
        }
    };

    const handleLogout = () => {
        getAuth().signOut();
    };

    
    // --- Notifications ---
    const handleMarkAllAsRead = async () => {
        if (!user) return;

        const unreadNotifs = notifications.filter(n => !n.isRead);
        if (unreadNotifs.length === 0) return;
        
        const batch = writeBatch(getDb());
        unreadNotifs.forEach(notif => {
            const notifRef = doc(collection(getDb(), 'users', user.uid, 'notifications'), notif.id);
            batch.update(notifRef, { isRead: true });
        });
        
        try {
            await batch.commit();
        } catch (error) {
            console.error("Error marking notifications as read:", error);
            addToast('Could not update notifications.', 'error');
        }
    };
    
    // --- Tip Action ---
    const handleSendTip = async (submission: Submission, amount: number, currency: 'JD TOKENS' | 'BDT') => {
        if (!user) {
            addToast('You must be logged in to send a tip.', 'error');
            throw new Error('User not logged in');
        }

        const userBalance = currency === 'BDT' ? userBdtBalance : userPoints;
        if (userBalance < amount) {
            addToast('Insufficient funds to send this tip.', 'error');
            throw new Error('Insufficient funds');
        }

        const batch = writeBatch(getDb());
        const tipperRef = doc(collection(getDb(), 'users'), user.uid);
        const tipperWalletRef = doc(collection(getDb(), 'wallets'), user.uid);
        const recipientRef = doc(collection(getDb(), 'users'), submission.userId);
        const recipientWalletRef = doc(collection(getDb(), 'wallets'), submission.userId);

        const balanceField = currency === 'BDT' ? 'bdtBalance' : 'points';

        batch.update(tipperWalletRef, { [balanceField]: getFieldValue().increment(-amount) });
        batch.update(recipientWalletRef, { [balanceField]: getFieldValue().increment(amount) });

        const tipperTxRef = doc(collection(tipperRef, 'transactions'));
        batch.set(tipperTxRef, {
            type: TransactionType.TIP_GIVEN,
            amount: -amount,
            currency: currency,
            description: `Tip for job: "${submission.jobTitle}"`,
            date: getFieldValue().serverTimestamp(),
        });

        const recipientTxRef = doc(collection(recipientRef, 'transactions'));
        batch.set(recipientTxRef, {
            type: TransactionType.TIP_RECEIVED,
            amount: amount,
            currency: currency,
            description: `Tip from job poster for: "${submission.jobTitle}"`,
            date: getFieldValue().serverTimestamp(),
        });
        
        const notificationRef = doc(collection(recipientRef, 'notifications'));
        batch.set(notificationRef, {
            userId: submission.userId,
            type: NotificationType.TIP_RECEIVED,
            message: `${user.displayName} tipped you ${amount.toFixed(2)} ${currency} for your work on "${submission.jobTitle}"!`,
            isRead: false,
            createdAt: getFieldValue().serverTimestamp(),
        });
        
        try {
            await batch.commit();
            addToast('Tip sent successfully!', 'success');
            setIsTipModalOpen(false);
        } catch (error) {
            console.error("Error sending tip:", error);
            addToast('Failed to send tip. Please try again.', 'error');
            throw error;
        }
    };
    
    const handleCloseAnnouncementModal = () => {
      if (latestAnnouncement) {
        localStorage.setItem(`seenAnnouncement_${latestAnnouncement.id}`, 'true');
      }
      setIsAnnouncementModalOpen(false);
    };

    // --- AI Assistant Handlers ---
    const handleAiEditJob = async (job: Job, newTitle?: string, newTask?: string) => {
        const jobRef = doc(collection(getDb(), 'jobs'), job.id.toString());
        const updates: { title?: string; task?: string } = {};
        if (newTitle) updates.title = newTitle;
        if (newTask) updates.task = newTask;

        if (Object.keys(updates).length === 0) {
          addToast("AI Assistant didn't request any changes.", 'info');
          return;
        }
        try {
          await updateDoc(jobRef, updates);
        } catch (error) {
          console.error("Error updating job via AI:", error);
          throw error; 
        }
    };

    const handleAiDeleteJob = async (job: Job) => {
        try {
          await handleConfirmDelete(job.id);
        } catch (error) {
          console.error("Error deleting job via AI:", error);
          throw error;
        }
    };

    const handleAiBoostJob = async (job: Job, duration: number, cost: number) => {
        if (!user) {
            throw new Error('User not logged in');
        }
        const jobRef = doc(collection(getDb(), 'jobs'), job.id.toString());
        const walletRef = doc(collection(getDb(), 'wallets'), user.uid);
        const userRef = doc(collection(getDb(), 'users'), user.uid);
        
        const batch = writeBatch(getDb());
        
        const boostEndTime = new Date(Date.now() + duration * 60 * 1000);
        
        batch.update(jobRef, { boostedUntil: getTimestamp().fromDate(boostEndTime) });
        batch.update(walletRef, { bdtBalance: getFieldValue().increment(-cost) });
        
        const transactionRef = doc(collection(userRef, 'transactions'));
        batch.set(transactionRef, {
            type: TransactionType.GIG_BOOST,
            amount: -cost,
            currency: 'BDT',
            description: `AI Boosted job: "${job.title}" for ${duration} mins`,
            date: getFieldValue().serverTimestamp(),
        });
        
        try {
            await batch.commit();
        } catch (error) {
            console.error("Error boosting job via AI:", error);
            throw error;
        }
    };

    // --- Render Logic ---
    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-100">
                <div className="text-center">
                    <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-sky-600 mx-auto"></div>
                    <p className="text-slate-500 mt-4 text-lg">Loading Your Dashboard...</p>
                </div>
            </div>
        );
    }

    if (permissionError) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-red-50 p-4">
                <div className="text-center max-w-lg bg-white p-8 rounded-lg shadow-lg border-2 border-red-200">
                    <h1 className="text-2xl font-bold text-red-700">Permission Denied</h1>
                    <p className="text-red-600 mt-2 mb-4">
                        We couldn't access some of your data due to a security rules misconfiguration. This is a problem on our end.
                    </p>
                    <div className="text-left text-sm text-red-500 bg-red-100 p-3 rounded-md">
                        <strong>The following errors occurred:</strong>
                        <ul className="list-disc list-inside mt-2">
                            {errorMessages.map((msg, idx) => <li key={idx}>{msg}</li>)}
                        </ul>
                    </div>
                     <p className="text-slate-500 mt-6 text-sm">Please contact support or try again later. We apologize for the inconvenience.</p>
                     <button onClick={() => getAuth().signOut()} className="mt-4 bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-5 text-sm rounded-full transition-colors">
                        Logout
                    </button>
                </div>
            </div>
        );
    }
    
    if (!user) {
        return <Auth />;
    }
    
    const unreadNotificationsCount = notifications.filter(n => !n.isRead).length;

    const filteredJobs = jobs
        .filter(job => 
            !hiddenJobIds.includes(job.id) &&
            job.remaining > 0 && 
            job.approvalStatus === JobApprovalStatus.APPROVED &&
            (selectedCategories.length === 0 || selectedCategories.includes(job.platform))
        )
        .sort((a, b) => {
            const now = new Date();
            const aIsBoosted = a.boostedUntil && typeof a.boostedUntil.toDate === 'function' && a.boostedUntil.toDate() > now;
            const bIsBoosted = b.boostedUntil && typeof b.boostedUntil.toDate === 'function' && b.boostedUntil.toDate() > now;

            if (aIsBoosted && !bIsBoosted) return -1; // Boosted 'a' comes first
            if (!aIsBoosted && bIsBoosted) return 1; // Boosted 'b' comes first

            // If both have the same boost status, sort by creation date (newest first)
            const timeA = a.createdAt && typeof a.createdAt.toDate === 'function' ? a.createdAt.toDate().getTime() : 0;
            const timeB = b.createdAt && typeof b.createdAt.toDate === 'function' ? b.createdAt.toDate().getTime() : 0;
            return timeB - timeA;
        });
    
    const userSubmittedJobIds = userSubmissions.map(s => s.jobId);
    
    const jobForTipModal = submissionToTip ? jobs.find(j => j.id === submissionToTip.jobId) : null;

  return (
    <div className="min-h-screen bg-gray-100">
      <Header
        userPoints={userPoints}
        userBdtBalance={userBdtBalance}
        unreadNotificationsCount={unreadNotificationsCount}
        onToggleNotifications={() => setIsNotificationsPanelOpen(prev => !prev)}
        onProfileClick={() => handleNavClick('profile')}
        photoURL={user.photoURL}
        displayName={user.displayName}
      />
      {isNotificationsPanelOpen && (
        <NotificationsPanel 
            notifications={notifications}
            announcement={latestAnnouncement}
            onMarkAllAsRead={handleMarkAllAsRead}
            onClose={() => setIsNotificationsPanelOpen(false)}
        />
      )}
      <nav className="bg-white/80 backdrop-blur-sm sticky top-[68px] z-20 border-b border-gray-200">
        <div className="container mx-auto px-4 flex justify-around">
          {['jobs', 'token', 'wallet', 'manage', 'refer', ].map((v) => (
             <button
                key={v}
                onClick={() => handleNavClick(v as any)}
                className={`py-3 px-2 font-semibold text-sm capitalize border-b-4 transition-all ${view === v ? 'border-sky-500 text-sky-600' : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-gray-300'}`}
              >
                {v}
              </button>
          ))}
        </div>
      </nav>
      <main className="container mx-auto p-4">
        {view === 'jobs' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
                 <h2 className="text-2xl font-bold text-slate-800">Available Jobs</h2>
                 <div className="flex items-center gap-2">
                    <button onClick={() => setIsFilterModalOpen(true)} className="bg-white border border-gray-300 text-slate-700 font-semibold py-2 px-4 text-sm rounded-full flex items-center gap-2 hover:bg-gray-100 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293.707L3.293 7.293A1 1 0 013 6.586V4z" /></svg>
                        Filter {selectedCategories.length > 0 && `(${selectedCategories.length})`}
                    </button>
                    <button onClick={() => setIsCreateModalOpen(true)} className="bg-sky-500 hover:bg-sky-600 text-white font-bold py-2 px-4 text-sm rounded-full transition-colors">
                      + Post Job
                    </button>
                </div>
            </div>
            {filteredJobs.length === 0 ? (
                <div className="text-center py-20 bg-white rounded-lg shadow-md">
                    <p className="text-slate-500 text-lg">No jobs available at the moment.</p>
                </div>
            ) : (
                filteredJobs.map(job => (
                    <JobCard
                        key={job.id}
                        job={job}
                        onClaim={handleClaimJob}
                        submittedJobIds={userSubmittedJobIds}
                        onHide={handleHideJob}
                        isOwnJob={job.posterId === user.uid}
                    />
                ))
            )}
          </div>
        )}
        {view === 'announcements' && <Announcements announcements={allAnnouncements} />}
        {view === 'token' && <TokenListing />}
        {view === 'wallet' && <Wallet userPoints={userPoints} userBdtBalance={userBdtBalance} onDepositSubmit={handleDepositSubmit} onWithdrawalSubmit={handleWithdrawalSubmit} />}
        {view === 'manage' && (
            <ManageGigs 
                postedJobs={postedJobs} 
                submissions={allSubmissions} 
                onEdit={(job) => { setJobToEdit(job); setIsEditModalOpen(true); }}
                onDelete={(jobId) => { 
                    const jobToDelete = jobs.find(j => j.id === jobId);
                    if (jobToDelete) {
                        setJobToDelete(jobToDelete);
                        setIsDeleteModalOpen(true);
                    }
                }}
                onApprove={handleApproveSubmission}
                onReject={(sub) => { setSubmissionToReject(sub); setIsRejectionModalOpen(true); }}
                onOpenBoost={(job) => { setJobToBoost(job); setIsBoostModalOpen(true); }}
                onOpenAddQuantity={(job) => { setJobToAddQuantity(job); setIsAddQuantityModalOpen(true); }}
                onOpenTipModal={(sub) => { setSubmissionToTip(sub); setIsTipModalOpen(true); }}
            />
        )}
        {view === 'refer' && (
            <Refer
                referralCode={userReferralCode}
                referredBy={referredBy}
                referralsCount={referralsCount}
                unclaimedReferralEarnings={unclaimedReferralEarnings}
                unclaimedBdtReferralEarnings={unclaimedBdtReferralEarnings}
                onClaimReferralEarnings={() => handleClaimReferralEarnings('JD TOKENS')}
                onClaimBdtReferralEarnings={() => handleClaimReferralEarnings('BDT')}
            />
        )}
        {view === 'profile' && (
            <Profile 
                userId={user.uid}
                userPoints={userPoints}
                userBdtBalance={userBdtBalance}
                transactions={transactions}
                jobs={jobs}
                submissions={userSubmissions}
                onReport={(sub) => { setSubmissionToReport(sub); setIsReportModalOpen(true); }}
                onLogout={handleLogout}
                displayName={displayName}
                email={email}
                createdAt={createdAt}
                photoURL={user.photoURL}
                totalEarnings={totalEarnings}
                totalBdtEarnings={totalBdtEarnings}
                gigsCompleted={gigsCompleted}
                gigsCreated={gigsCreated}
                onNavigate={handleNavClick}
                onOpenEditProfile={() => setIsEditProfileModalOpen(true)}
            />
        )}
      </main>
      
      {/* --- Modals --- */}
      <CreateJobModal 
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onAddJob={handleAddJob}
        userPoints={userPoints}
        userBdtBalance={userBdtBalance}
      />
      <ConfirmationModal
        isOpen={isConfirmationModalOpen}
        onClose={() => setIsConfirmationModalOpen(false)}
        onConfirm={handleConfirmSubmission}
        job={jobToConfirm}
      />
      <EditJobModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onEditJob={handleEditJob}
        jobToEdit={jobToEdit}
      />
      <RejectionModal 
        isOpen={isRejectionModalOpen}
        onClose={() => setIsRejectionModalOpen(false)}
        onConfirm={handleRejectSubmission}
        submission={submissionToReject}
      />
       <ReportModal 
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        onConfirm={handleReport}
        submission={submissionToReport}
      />
       <DeleteConfirmationModal
            isOpen={isDeleteModalOpen}
            onClose={() => setIsDeleteModalOpen(false)}
            onConfirm={() => jobToDelete && handleConfirmDelete(jobToDelete.id)}
            jobTitle={jobToDelete?.title || ''}
            pendingCount={jobToDelete?.pendingCount || 0}
            refundAmount={jobToDelete ? (jobToDelete.reward * 1.10) * jobToDelete.remaining : 0}
            currency={jobToDelete?.currency || ''}
        />
        <BoostConfirmationModal 
            isOpen={isBoostModalOpen}
            onClose={() => setIsBoostModalOpen(false)}
            onConfirm={handleConfirmBoost}
            job={jobToBoost}
            userBdtBalance={userBdtBalance}
        />
        <AddQuantityModal
            isOpen={isAddQuantityModalOpen}
            onClose={() => setIsAddQuantityModalOpen(false)}
            onConfirm={handleConfirmAddQuantity}
            job={jobToAddQuantity}
            userPoints={userPoints}
            userBdtBalance={userBdtBalance}
        />
        <FilterModal
            isOpen={isFilterModalOpen}
            onClose={() => setIsFilterModalOpen(false)}
            onApply={setSelectedCategories}
            currentSelection={selectedCategories}
        />
         <TipModal
            isOpen={isTipModalOpen}
            onClose={() => setIsTipModalOpen(false)}
            onConfirm={handleSendTip}
            submission={submissionToTip}
            job={jobForTipModal}
            userPoints={userPoints}
            userBdtBalance={userBdtBalance}
        />
        <AnnouncementModal
            isOpen={isAnnouncementModalOpen}
            onClose={handleCloseAnnouncementModal}
            announcement={latestAnnouncement}
        />
        <EditProfileModal
            isOpen={isEditProfileModalOpen}
            onClose={() => setIsEditProfileModalOpen(false)}
            onSave={handleSaveProfile}
            currentName={displayName}
            currentPhotoURL={user.photoURL}
        />
        <button
            onClick={() => setIsAiAssistantModal(true)}
            className="fixed bottom-6 right-6 bg-gradient-to-r from-purple-500 to-sky-500 text-white w-16 h-16 rounded-full shadow-lg flex items-center justify-center transform hover:scale-110 transition-transform duration-200 z-40"
            aria-label="Open AI Assistant"
        >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
        </button>
        <AiAssistantModal
            isOpen={isAiAssistantModalOpen}
            onClose={() => setIsAiAssistantModal(false)}
            onAddJob={handleAddJob}
            onEditJob={handleAiEditJob}
            onDeleteJob={handleAiDeleteJob}
            onBoostJob={handleAiBoostJob}
            userPoints={userPoints}
            userBdtBalance={userBdtBalance}
            postedJobs={postedJobs}
            messages={aiMessages}
            setMessages={setAiMessages}
            chatSessionRef={chatSessionRef}
            aiLanguage={aiLanguage}
            onSetAiLanguage={onSetAiLanguage}
        />
    </div>
  );
}