import React from 'react';

const WordChat: React.FC = () => {
    return null;
};

export default WordChat;
