import React, { useState } from 'react';
import { Job } from '../types';

interface BoostConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (duration: number, cost: number) => void;
  job: Job | null;
  userBdtBalance: number;
}

const boostOptions = [
    { duration: 30, cost: 6 },
    { duration: 45, cost: 7.5 },
    { duration: 60, cost: 10 },
];

const BoostConfirmationModal: React.FC<BoostConfirmationModalProps> = ({ isOpen, onClose, onConfirm, job, userBdtBalance }) => {
  const [selectedDuration, setSelectedDuration] = useState(30);

  if (!isOpen || !job) return null;

  const selectedOption = boostOptions.find(o => o.duration === selectedDuration)!;
  const canAfford = userBdtBalance >= selectedOption.cost;

  const handleConfirm = () => {
    if (canAfford) {
        onConfirm(selectedOption.duration, selectedOption.cost);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-md transform transition-all scale-95 animate-modal-enter">
        <div className="flex justify-between items-center p-4 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-yellow-500 flex items-center gap-2">🚀 Boost Job</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-800 text-2xl">&times;</button>
        </div>
        <div className="p-6">
          <div className="text-center">
            <p className="text-slate-600">Choose a duration</p>
            <div className="grid grid-cols-3 gap-3 mt-4">
                {boostOptions.map(option => (
                    <button
                        key={option.duration}
                        onClick={() => setSelectedDuration(option.duration)}
                        className={`p-3 rounded-lg border text-center transition-all ${
                            selectedDuration === option.duration
                                ? 'bg-yellow-500 text-white border-yellow-500 shadow-md'
                                : 'bg-gray-100 text-slate-700 border-gray-300 hover:bg-gray-200'
                        }`}
                    >
                        <p className="font-bold">{option.duration} mins</p>
                        <p className="text-sm">৳ {option.cost.toFixed(2)}</p>
                    </button>
                ))}
            </div>
            <div className={`mt-6 p-3 rounded-md text-sm ${canAfford ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}>
                <p>Cost: <span className="font-bold">{selectedOption.cost.toFixed(2)} BDT</span></p>
                <p className="mt-1">Your BDT balance: {userBdtBalance.toFixed(2)} BDT</p>
                {!canAfford && <p className="font-bold mt-1">Insufficient BDT balance.</p>}
            </div>
          </div>
        </div>
        <div className="p-4 bg-gray-50 flex justify-end gap-4 border-t border-gray-200">
          <button type="button" onClick={onClose} className="bg-gray-200 hover:bg-gray-300 text-slate-800 font-bold py-2 px-4 rounded-full transition-colors">
            Cancel
          </button>
          <button
            onClick={handleConfirm}
            disabled={!canAfford}
            className="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded-full transition-colors disabled:bg-gray-200 disabled:cursor-not-allowed disabled:text-gray-400"
          >
            Confirm Boost
          </button>
        </div>
        <style dangerouslySetInnerHTML={{ __html: `
          @keyframes modal-enter {
            from { opacity: 0; transform: scale(0.9); }
            to { opacity: 1; transform: scale(1); }
          }
          .animate-modal-enter { animation: modal-enter 0.2s ease-out forwards; }
        `}} />
      </div>
    </div>
  );
};

export default BoostConfirmationModal;