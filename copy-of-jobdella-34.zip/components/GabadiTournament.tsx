import React from 'react';

const GabadiTournament: React.FC = () => {
    return null;
};

export default GabadiTournament;
