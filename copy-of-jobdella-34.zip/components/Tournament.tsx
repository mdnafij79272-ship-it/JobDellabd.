import React from 'react';

const Tournament: React.FC = () => {
    return null;
};

export default Tournament;
