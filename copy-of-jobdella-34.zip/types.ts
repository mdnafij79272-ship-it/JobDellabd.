export enum Platform {
  YOUTUBE = 'YOUTUBE',
  FACEBOOK = 'FACEBOOK',
  INSTAGRAM = 'INSTAGRAM',
  TWITTER = 'TWITTER',
  TIKTOK = 'TIKTOK',
  LIKEE = 'LIKEE',
  TELEGRAM = 'TELEGRAM',
  WHATSAPP = 'WHATSAPP',
  LINKEDIN = 'LINKEDIN',
  REDDIT = 'REDDIT',
  MEDIUM = 'MEDIUM',
  DISCORD = 'DISCORD',
  QUORA = 'QUORA',
  SIGN_UP = 'SIGN_UP',
  SEARCH_CLICK = 'SEARCH_CLICK',
  PROMOTION = 'PROMOTION',
  MOBILE_APP = 'MOBILE_APP',
  SHARE = 'SHARE',
  GMAIL_ACCOUNT = 'GMAIL_ACCOUNT',
  COMMENT = 'COMMENT',
  VISITOR = 'VISITOR',
  COMPUTER_PROGRAMS = 'COMPUTER_PROGRAMS',
  WRITE_ARTICLE = 'WRITE_ARTICLE',
  ANSWERS = 'ANSWERS',
  VIEWS = 'VIEWS',
  REFER_PROGRAM = 'REFER_PROGRAM',
  SURVEY = 'SURVEY',
  FACEBOOK_INVITE = 'FACEBOOK_INVITE',
  REVIEW = 'REVIEW',
  ADS_CLICK = 'ADS_CLICK',
  ASSIGNMENT = 'ASSIGNMENT',
  STORY = 'STORY',
  TYPING = 'TYPING',
  EDIT = 'EDIT',
  GRAPHICS_DESIGN = 'GRAPHICS_DESIGN',
  BLOG_WEBSITE = 'BLOG_WEBSITE',
  KYC_SUBMIT = 'KYC_SUBMIT',
  REEL_SHORT = 'REEL_SHORT',
  APP_PRE_TESTER = 'APP_PRE_TESTER',
  AIRDROP_JOIN = 'AIRDROP_JOIN',
  NEED_FOLLOWER = 'NEED_FOLLOWER',
  OTHERS = 'OTHERS',
}

export const platformNameMap: Record<Platform, string> = {
  [Platform.YOUTUBE]: 'YouTube',
  [Platform.FACEBOOK]: 'Facebook',
  [Platform.INSTAGRAM]: 'Instagram',
  [Platform.TWITTER]: 'Twitter',
  [Platform.TIKTOK]: 'Tik-tok',
  [Platform.LIKEE]: 'Likee',
  [Platform.TELEGRAM]: 'Telegram',
  [Platform.WHATSAPP]: 'WhatsApp',
  [Platform.LINKEDIN]: 'Linkedin',
  [Platform.REDDIT]: 'Reddit',
  [Platform.MEDIUM]: 'Medium',
  [Platform.DISCORD]: 'Discord',
  [Platform.QUORA]: 'Quora',
  [Platform.SIGN_UP]: 'Sign Up',
  [Platform.SEARCH_CLICK]: 'Search / Click',
  [Platform.PROMOTION]: 'Promotion',
  [Platform.MOBILE_APP]: 'Mobile Application',
  [Platform.SHARE]: 'Share',
  [Platform.GMAIL_ACCOUNT]: 'Gmail Account',
  [Platform.COMMENT]: 'Comment',
  [Platform.VISITOR]: 'Visitor',
  [Platform.COMPUTER_PROGRAMS]: 'Computer Programs',
  [Platform.WRITE_ARTICLE]: 'Write an Article',
  [Platform.ANSWERS]: 'Answers',
  [Platform.VIEWS]: 'Views',
  [Platform.REFER_PROGRAM]: 'Refer Program',
  [Platform.SURVEY]: 'Survey',
  [Platform.FACEBOOK_INVITE]: 'Facebook-Invite',
  [Platform.REVIEW]: 'Review',
  [Platform.ADS_CLICK]: 'Ads Click',
  [Platform.ASSIGNMENT]: 'Assignment',
  [Platform.STORY]: 'Story',
  [Platform.TYPING]: 'Typing',
  [Platform.EDIT]: 'Edit',
  [Platform.GRAPHICS_DESIGN]: 'Graphics Design',
  [Platform.BLOG_WEBSITE]: 'Blog Website',
  [Platform.KYC_SUBMIT]: 'Kyc Submit',
  [Platform.REEL_SHORT]: 'Reel / Short',
  [Platform.APP_PRE_TESTER]: 'App Pre Tester',
  [Platform.AIRDROP_JOIN]: 'Airdrop Join',
  [Platform.NEED_FOLLOWER]: 'Need Follower',
  [Platform.OTHERS]: 'Others',
};


export enum SubmissionStatus {
  PENDING = 'PENDING',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
}

export interface Submission {
  id: string;
  userId: string;
  userDisplayName?: string;
  userIp?: string;
  jobId: number;
  jobTitle: string; 
  proof: string;
  status: SubmissionStatus;
  rejectionReason?: string;
  createdAt: any; // For Firestore Timestamp
}

export enum JobApprovalStatus {
  PENDING = 'PENDING',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
}

export enum SocialSubcategory {
  FOLLOW_SUBSCRIBE = 'FOLLOW_SUBSCRIBE',
  FULL_ENGAGEMENT = 'FULL_ENGAGEMENT',
}

export const socialSubcategoryNameMap: Record<SocialSubcategory, string> = {
  [SocialSubcategory.FOLLOW_SUBSCRIBE]: 'Follow / Subscribe',
  [SocialSubcategory.FULL_ENGAGEMENT]: 'Full Engagement (Like, Comment, etc.)',
};

export enum TwitterSubcategory {
    FOLLOW = 'FOLLOW',
    ENGAGEMENT = 'ENGAGEMENT',
}

export const twitterSubcategoryNameMap: Record<TwitterSubcategory, string> = {
    [TwitterSubcategory.FOLLOW]: 'Follow',
    [TwitterSubcategory.ENGAGEMENT]: 'Views + Like + Comment',
};


export interface Job {
  id: number;
  posterId: string;
  platform: Platform;
  subcategory?: SocialSubcategory;
  twitterSubcategory?: TwitterSubcategory;
  title: string;
  task: string;
  proofRequirement: string;
  reward: number;
  currency: 'JD TOKENS' | 'BDT';
  quantity: number;
  remaining: number;
  pendingCount?: number;
  boostedUntil?: any; // For Firestore Timestamp
  createdAt: any;
  approvalStatus: JobApprovalStatus;
  rejectionReason?: string;
}

export enum TransactionType {
  GIG_POST = 'GIG_POST',
  GIG_REFUND = 'GIG_REFUND',
  GIG_BOOST = 'GIG_BOOST',
  GIG_ADD_QUANTITY = 'GIG_ADD_QUANTITY',
  GIG_COMPLETED = 'GIG_COMPLETED',
  SIGNUP_BONUS = 'SIGNUP_BONUS',
  REFERRAL_SIGNUP_BONUS = 'REFERRAL_SIGNUP_BONUS',
  REFERRAL_COMMISSION = 'REFERRAL_COMMISSION',
  EARNINGS_COMMISSION = 'EARNINGS_COMMISSION',
  REPORT_COMPENSATION = 'REPORT_COMPENSATION',
  REPORT_PENALTY = 'REPORT_PENALTY',
  REFERRAL_EARNINGS_CLAIM = 'REFERRAL_EARNINGS_CLAIM',
  DEPOSIT_APPROVED = 'DEPOSIT_APPROVED',
  WITHDRAW_REQUEST = 'WITHDRAW_REQUEST',
  QUANTITY_REQUEST_REFUND = 'QUANTITY_REQUEST_REFUND',
  TIP_GIVEN = 'TIP_GIVEN',
  TIP_RECEIVED = 'TIP_RECEIVED',
}

// FIX: Added the missing 'Transaction' type to resolve import errors.
export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  currency: 'JD TOKENS' | 'BDT';
  description: string;
  date: any; // For Firestore Timestamp on write, becomes Date on read
}

export enum NotificationType {
  REFERRAL_COMMISSION = 'REFERRAL_COMMISSION',
  EARNINGS_COMMISSION = 'EARNINGS_COMMISSION',
  GIG_AUTO_APPROVED = 'GIG_AUTO_APPROVED',
  DEPOSIT_PENDING = 'DEPOSIT_PENDING',
  DEPOSIT_APPROVED = 'DEPOSIT_APPROVED',
  DEPOSIT_REJECTED = 'DEPOSIT_REJECTED',
  REFERRAL_GIG_POST_COMMISSION = 'REFERRAL_GIG_POST_COMMISSION',
  QUANTITY_APPROVED = 'QUANTITY_APPROVED',
  QUANTITY_REJECTED = 'QUANTITY_REJECTED',
  TIP_RECEIVED = 'TIP_RECEIVED',
}

export interface Notification {
  id: string;
  userId: string;
  type: NotificationType;
  message: string;
  isRead: boolean;
  createdAt: any; // For Firestore Timestamp
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  createdAt: any; // For Firestore Timestamp
  isActive: boolean;
}

export interface Deposit {
    id: string;
    userId: string;
    senderNumber: string;
    amount: number;
    transactionId: string;
    status: 'PENDING' | 'APPROVED' | 'REJECTED';
    createdAt: any; // Firestore Timestamp
    rejectionReason?: string;
    referrerBonusProcessed?: boolean; // New field to track if referrer bonus has been processed
}

// FIX: Added missing Advertisement type to resolve import error in AdvertisementCard.tsx.
export interface Advertisement {
  id: string;
  imageUrl: string;
  targetUrl: string;
}

// FIX: Add missing Message type for the AI Assistant feature.
export interface Message {
  role: 'user' | 'model' | 'system' | 'error';
  text: string;
}