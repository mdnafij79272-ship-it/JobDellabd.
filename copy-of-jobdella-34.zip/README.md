

# JobDella - Micro-Job & Crypto Platform

A dynamic micro-job and crypto exchange platform where users can earn by completing simple social media tasks.

## 📖 About the Project

JobDella connects people who need small online tasks done (like subscribing to a YouTube channel, liking a Facebook page, or leaving a comment) with a global workforce ready to complete them for a reward. The platform is built around a dual-currency system, offering both a native utility token (JDT) and real-world currency (BDT) to facilitate a flexible and engaging micro-economy.

## ✨ Key Features

-   **Post & Browse Jobs**: Users can create jobs for a wide variety of social media and online platforms or browse a real-time list of available tasks.
-   **Dual Currency Wallet**: Manage both **JobDella Tokens (JDT ⚡)** and **Bangladeshi Taka (BDT ৳)** in a single, integrated wallet.
-   **Secure Submissions & Review**: Workers submit proof of completion, and job posters can easily review, approve, or reject submissions from a dedicated management panel.
-   **Deposit & Withdrawal System**: Easily deposit BDT via bKash to fund jobs and withdraw earnings.
-   **Referral Program**: Invite friends with a unique code and earn commissions from their sign-ups, deposits, and task earnings.
-   **Real-time Notifications**: Get instant updates on submission approvals, earnings, referral bonuses, and platform news.
-   **Job Boosting**: Posters can pay a small fee to "boost" their jobs, giving them premium placement on the job list to attract workers faster.
-   **AI Assistant**: An integrated AI helper ("Della") to assist users with posting jobs and navigating the platform.

## 💻 Technologies Used

-   **Frontend**: React, TypeScript, Tailwind CSS
-   **Backend & Database**: Firebase (Authentication, Firestore)
-   **AI Integration**: Google Gemini API

## 🚀 How It Works

### For Workers (Earners)

1.  **Sign Up**: Create an account using your Gmail address.
2.  **Browse Jobs**: Navigate to the "Available Jobs" list to see all open tasks.
3.  **Complete Task**: Pick a job, carefully read the instructions, and complete the required action.
4.  **Submit Proof**: Provide the proof requested by the job poster (e.g., a screenshot link, your username).
5.  **Get Paid**: Once the job poster approves your submission, your wallet is instantly credited with the reward!

### For Posters (Employers)

1.  **Fund Your Wallet**: Deposit BDT into your account via the bKash option in the "Wallet" section.
2.  **Post a Job**: Click the "+ Post Job" button, fill in the details of your task, set the reward, and choose the quantity.
3.  **Go Live**: Your job is posted to the public job list for workers to complete.
4.  **Manage Submissions**: Go to the "Manage Gigs" section to see all the proofs submitted by workers.
5.  **Approve & Pay**: Review the proofs. If the work is done correctly, approve it to transfer the payment to the worker.

## 💰 The Currency System

-   **JobDella Token (JDT) ⚡**: The platform's native utility token. It's earned by completing jobs and through bonuses (like the sign-up bonus). It can be used to post new jobs. The future goal is for JDT to be a tradable crypto asset.
-   **Bangladeshi Taka (BDT) ৳**: The real-world currency wallet. This is used for deposits, withdrawals, posting higher-value jobs, and purchasing premium features like Job Boosting.

## 🤝 Referral System

-   **Share Your Code**: Find your unique referral code in the "Refer" section.
-   **Earn on Sign-up**: When a new user signs up with your code, they receive 5 JD TOKENS, and you (the referrer) also receive 5 JD TOKENS. There are no other welcome bonuses in points or BDT.
-   **Earn on Deposits**: Receive a 5% BDT commission every time your referred friend makes a deposit.
-   **Earn on Tasks**: Receive a 5% commission on the earnings from every job your referred friend completes, with the commission paid in the respective job's currency (JD TOKENS or BDT).

আমার রেফার কোড ব্যবহার করে কেউ অ্যাকাউন্ট খুললে, নতুন ব্যবহারকারী ৫ JD টোকেন বোনাস পাবে এবং আপনি (রেফারার) ৫ JD টোকেন বোনাস পাবেন। আপনার রেফার করা ব্যক্তি যেকোনো কাজ সম্পন্ন করলে, সেই কাজের কারেন্সি অনুযায়ী আপনি তার উপার্জনের ৫% বোনাস পাবেন। এছাড়াও, আপনার রেফার করা ব্যক্তি কোনো BDT ডিপোজিট করলে, আপনি সেই ডিপোজিটের ৫% BDT বোনাস পাবেন। কোনো অতিরিক্ত ওয়েলকাম বোনাস পয়েন্ট বা BDT দেওয়া হবে না।
